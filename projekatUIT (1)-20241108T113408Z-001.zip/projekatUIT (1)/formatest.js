function saveData() {
    let mail, tel, film, vreme, dan, karte;
    mail = document.getElementById("mail").value;
    tel = document.getElementById("tel").value;
    film = document.getElementById("film").value;
    vreme = document.getElementById("vreme").value;
    dan = document.getElementById("dan").value;
    karte = document.getElementById("karte").value;
    var tabela = document.getElementById("tabela");



    localStorage.setItem("mail", mail);
    localStorage.setItem("tel", tel);
    localStorage.setItem("film", film);
    localStorage.setItem("vreme", vreme);
    localStorage.setItem("dan", dan);
    localStorage.setItem("karte", karte);
  
    let termin = document.getElementsByClassName("vreme");
    for(var i=0; i<radio.length;i++){
        if(radio[i].checked===true){
            vrednost= radio[i].value;
        }
    }
    if(mail==="" || mail===null)
    {
        document.getElementById("mail").style.border='3px solid red';
        alert("Niste uneli email");
        return false;
    }   
    else if(tel==="" || tel===null)
    {
        document.getElementById("tel").style.border='3px solid red';
        alert("Niste uneli broj telefona");
        return false;
    } 
    else if(film==="" || film===null)
    {
        document.getElementById("film").style.border='3px solid red';
        alert("Niste izabrali film");
        return false;
    }
    else if(vreme==="" || vreme===null)
    {
        document.getElementById("time").style.border='3px solid red';
        alert("Niste izabrali vreme");
        return false;
    }
    else if(dan==="" || dan===null)
    {
        document.getElementById("dan").style.border='3px solid red';
        alert("Niste izabrali dan");
        return false;
    }
    else if(karte==="" || karte===null)
    {
        document.getElementById("karte").style.border='3px solid red';
        alert("Niste izabrali broj karata");
        return false;
    }
    
    else
    {
        alert("Uspesno ste poslali formu")
        return true;
    }
  }

  

  