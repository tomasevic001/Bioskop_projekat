let mail = localStorage.getItem("mail");
let tel = localStorage.getItem("tel");
let film = localStorage.getItem("film");
let vreme = localStorage.getItem("vreme");
let dan = localStorage.getItem("dan");
let karte = localStorage.getItem("karte");
var tabela = document.getElementById("tabela");

localStorage.clear();

document.getElementById("mail").innerHTML = mail;
document.getElementById("tel").innerHTML = tel;
document.getElementById("film").innerHTML = film;
document.getElementById("vreme").innerHTML = vreme;
document.getElementById("dan").innerHTML = dan;
document.getElementById("karte").innerHTML = karte;

function deleteData() {
  localStorage.clear();
  document.getElementById("mail").innerHTML = " ";
  document.getElementById("tel").innerHTML = " ";
  document.getElementById("film").innerHTML = " ";
  document.getElementById("vreme").innerHTML = " ";
  document.getElementById("dan").innerHTML = " ";
  document.getElementById("karte").innerHTML = " ";
}
for(let i=0; i<formList.length; i++){
    let form = formList[i];
    table += `<tr><td>${form.mail || 'N/A'}</td><td>${form.tel || 'N/A'}</td><td>${form.film || 'N/A'}</td><td>${form.vreme || 'N/A'}</td><td>${form.karte || 'N/A'}</td></tr>`;
  }